if __name__ == "__main__":
    from bean_inquiry.cli import app
    app()
